#this function will take a list of 1x4 matrices of complex
"""numbers and return a list of lists where each element has 8 numbers r,and im
coefficients of the numbers in the 2x2 matrix, without duplicates
my_list = [[1.0, (1+1j),0, (1+2j)], [(1+1j), (1+2j), (1+1j), (1+2j)]]
  """
def data_gen(myarray): 
    import numpy as np
    import math
    import cmath
    l_m = len(myarray)
    #myarray = np.array(myarray)
    
    data_list = []
  
    for i in range(len(myarray)):
        #print("i= ",i)
        
        a = myarray[i][0].real
        b = myarray[i][0].imag
        c = myarray[i][1].real
        d = myarray[i][1].imag
        e = myarray[i][2].real
        f = myarray[i][2].imag
        g = myarray[i][3].real
        h = myarray[i][3].imag
        

        data = [(a,b,c,d,e,f,g,h)]
        #print("data: ",data)
        data_list.append(data)
        
    return data_list
"""out[put has the form [[(1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 2.0)],
[(1.0, 1.0, 1.0, 2.0, 1.0, 1.0, 1.0, 2.0)]]   """
        
    
