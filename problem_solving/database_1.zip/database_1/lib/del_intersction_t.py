# delete dups in outcomes table
def d_inter(data_base,num):
    import sqlite3 as lite
    filename = str('%s'%data_base)+str('.db')
    conn = lite.connect(filename)
    cur = conn.cursor()
    if num == 1:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes1 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes1 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 2:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes2 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes2 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 3:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes3 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes3 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
            
    if num == 5:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes5 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes5 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    
    if num == 4:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes4 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes4 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 6:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes6 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes6 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 7:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes7 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes7 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 8:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes8 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes8 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 9:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes9 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes9 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 10:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes10 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes10 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 11:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes11 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes11 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 12:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes12 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes12 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 13:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes13 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes13 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
            
    if num == 15:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes15 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes15 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    
    if num == 14:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes14 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes14 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 16:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes16 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes16 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    if num == 17:
        cur.execute("""SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r  FROM outcomes17 
         INTERSECT SELECT Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r FROM master_list; """)
        final_result = cur.fetchall()
        
        def deleteSqliteRecord(element):
            element = str(element)
            element = element.strip()
            element = element.replace(",","")
            element = element.replace("(","")
            element = element.replace(")","")
            element = element.replace("'","")
            #print(element)
        
            sql_update_query = """DELETE from outcomes17 where strngy = ?"""
            cur.execute(sql_update_query, (element, ))
            conn.commit()
        for each in final_result:
            deleteSqliteRecord(each)
    
        

    
    
    conn.commit()
    conn.close()

