#qu_table_create_fn.py       10/8/2020
def create_table(data_base,num):
   
    import sqlite3
    import numpy as np
    filename = str('%s'%data_base)+str('.db')
    

    conn = sqlite3.connect(filename)
    cursor = conn.cursor()
    
                           
    if num == 1:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes1 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num ==2:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes2 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num ==3:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes3 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    if num == 4:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes4 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num ==5:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes5 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num ==6:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes6 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    if num == 7:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes7 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num ==8:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes8 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num ==9:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes9 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    if num == 10:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes10 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num ==11:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes11 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num ==12:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes12 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num == 13:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes13 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    if num == 14:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes14 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num == 15:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes15 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    elif num == 16:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes16 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    if num == 17:
        cursor.execute("""CREATE TABLE IF NOT EXISTS outcomes17 (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
    if num == 'm':
        cursor.execute("""CREATE TABLE IF NOT EXISTS master_list (
        Element1_r	REAL,
	Element1_i	REAL,
	Element2_r	REAL,
	Element2_i	REAL,
	Element3_r	REAL,
	Element3_i	REAL,
	Element4_r	REAL,
	Element4_i	REAL);""")
        
         
    
    
    conn.commit()
    conn.close()
   
