#query_table_delete_fnv1.py

def delete_table(data_base,num):
    
    import sqlite3
    import numpy as np
    filename = str('%s'%data_base)+str('.db')

    conn = sqlite3.connect(filename)
    cursor = conn.cursor()
    if num == 1:
        cursor.execute("""DROP TABLE IF EXISTS outcomes1;""")
    elif num == 2:
        cursor.execute("""DROP TABLE IF EXISTS outcomes2;""")
    elif num == 3:
        cursor.execute("""DROP TABLE IF EXISTS outcomes3;""")
    elif num == 4:
        cursor.execute("""DROP TABLE IF EXISTS outcomes4;""")
    elif num == 5:
        cursor.execute("""DROP TABLE IF EXISTS outcomes5;""")
    elif num == 6:
        cursor.execute("""DROP TABLE IF EXISTS outcomes6;""")
    elif num == 7:
        cursor.execute("""DROP TABLE IF EXISTS outcomes7;""")
    elif num == 8:
        cursor.execute("""DROP TABLE IF EXISTS outcomes8;""")
    elif num == 9:
        cursor.execute("""DROP TABLE IF EXISTS outcomes9;""")
    elif num == 10:
        cursor.execute("""DROP TABLE IF EXISTS outcomes10;""")
    elif num == 11:
        cursor.execute("""DROP TABLE IF EXISTS outcomes11;""")
    elif num == 12:
        cursor.execute("""DROP TABLE IF EXISTS outcomes12;""")
    elif num == 13:
        cursor.execute("""DROP TABLE IF EXISTS outcomes13;""")
    elif num == 14:
        cursor.execute("""DROP TABLE IF EXISTS outcomes14;""")
    elif num == 15:
        cursor.execute("""DROP TABLE IF EXISTS outcomes15;""")
    elif num == 16:
        cursor.execute("""DROP TABLE IF EXISTS outcomes16;""")
    elif num == 17:
        cursor.execute("""DROP TABLE IF EXISTS outcomes17;""")

    elif num == "m":
        cursor.execute("""DROP TABLE IF EXISTS master_list;""")


              
 
    conn.commit()
    conn.close()
    
