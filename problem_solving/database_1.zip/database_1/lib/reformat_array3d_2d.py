# this will reformat a  nx2x2 np array into a nx4 list or array
def reformat(my_array):
    import numpy as np
    length = len(my_array)
    
    my_array = np.array(my_array)
    my_array = my_array.reshape(length,4)
    return my_array
