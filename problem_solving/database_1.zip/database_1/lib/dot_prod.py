def dot_product(outcomes): 
    """ outcomes needs to be a list of lists[[1,0,0,0],[0,0,1,0]], each elemtmental list has
    4 complex numbers 2 representing the the contents of each row of a 2x2 matrix"""
    import numpy as np
    import math
    import cmath
    root2 = math.sqrt(2)
    turn = np.array([[[complex(1/root2,0),complex(1/root2,0)],[complex(1/root2,0),complex(-1/root2,0)]],[[1,0],[0,complex(1/root2,1/root2)]],[[1,0],[0,complex(0,1)]]],dtype = complex)
    new_matrix = []
    for i in range(len(outcomes)):            
        for tu in turn:
            out = outcomes[i]
            
            out_np = np.array(out)
            out_s = np.split(out_np,2) 
            newelement = np.dot(out_s,tu)  #newelement is the result of the dot product 
             
            new_matrix.append(newelement)
            
        i=i+1
    new_matrix = np.array(new_matrix)
    """new_matrix this is the array of newelements array([[[0.70710678+0.j, 0.70710678+0.j],
            [0.        +0.j, 0.        +0.j]],

           [[1.        +0.j, 0.        +0.j],
            [0.        +0.j, 0.        +0.j]],

           [[1.        +0.j, 0.        +0.j],
            [0.        +0.j, 0.        +0.j]],

           [[0.        +0.j, 0.        +0.j],
            [0.70710678+0.j, 0.70710678+0.j]],

           [[0.        +0.j, 0.        +0.j],
            [1.        +0.j, 0.        +0.j]],

           [[0.        +0.j, 0.        +0.j],
            [1.        +0.j, 0.        +0.j]]])"""
    
    return new_matrix
