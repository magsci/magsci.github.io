def three_matrices(data_base):
    import numpy as np
    import math
    import cmath
    import my_database_sow_all2
    """ this changes the np aprray into data  """
    root2 = math.sqrt(2)
    turn = np.array([[[complex(1/root2,0),complex(1/root2,0)],[complex(1/root2,0),complex(-1/root2,0)]],[[1,0],[0,complex(1/root2,1/root2)]],[[1,0],[0,complex(0,1)]]],dtype = complex)
    l_m = len(turn)

    final_matrix = turn.reshape(l_m,4)
    turn = final_matrix.tolist()

    for i in range(len(turn)):
        
        
        a = turn[i][0].real
        b = turn[i][0].imag
        c = turn[i][1].real
        d = turn[i][1].imag
        e = turn[i][2].real
        f = turn[i][2].imag
        g = turn[i][3].real
        h = turn[i][3].imag
        

        data = [(a,b,c,d,e,f,g,h)]
        #print("data  ",data)
        
        my_database_sow_all2.sow_data(data_base,data,"m")
        my_database_sow_all2.sow_data(data_base,data,1)
