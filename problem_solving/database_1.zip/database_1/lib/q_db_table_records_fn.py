# q_db_table_records.py   10/8/2020
def get_all(data_base,num):
    # returns data as nx8 of numerical values 
    import sqlite3
    import numpy as np
    filename = str('%s'%data_base)+str('.db')
    conn = sqlite3.connect(filename)
    cursor = conn.cursor()
    

    if num == 1:
        cursor.execute("SELECT  * FROM outcomes1;")
    elif num == 2:
        cursor.execute("SELECT  * FROM outcomes2;")
    elif num == 3:
        cursor.execute("SELECT  * FROM outcomes3;")
    elif num == 4:
        cursor.execute("SELECT  * FROM outcomes4;")
    elif num == 5:
        cursor.execute("SELECT  * FROM outcomes5;")
    elif num == 6:
        cursor.execute("SELECT  * FROM outcomes6;")
    elif num == 7:
        cursor.execute("SELECT  * FROM outcomes7;")
    elif num == 8:
        cursor.execute("SELECT  * FROM outcomes8;")
    elif num == 9:
        cursor.execute("SELECT  * FROM outcomes9;")
    elif num == 10:
        cursor.execute("SELECT  * FROM outcomes10;")
    elif num == 11:
        cursor.execute("SELECT  * FROM outcomes11;")
    elif num == 12:
        cursor.execute("SELECT  * FROM outcomes12;")
    elif num == 13:
        cursor.execute("SELECT  * FROM outcomes13;")
    elif num == 14:
        cursor.execute("SELECT  * FROM outcomes114;")
    elif num == 15:
        cursor.execute("SELECT  * FROM outcomes15;")
    elif num == 16:
        cursor.execute("SELECT  * FROM outcomes16;")
    elif num == 17:
        cursor.execute("SELECT  * FROM outcomes17;")

    elif num == "m":
        cursor.execute("SELECT  * FROM master_list;")


              
    final_result = cursor.fetchall()
    length = len(final_result)
    
    final_result = np.array(final_result)
    
    final_result = final_result.reshape(length,8)
    return final_result
    
    conn.commit()
    conn.close()
    
