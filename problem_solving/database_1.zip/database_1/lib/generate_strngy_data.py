# generate_strngy will add the string data to string field
def make_strng(data_base,num):
    import sqlite3 as lite
    filename = str('%s'%data_base)+str('.db')
    conn = lite.connect(filename)
    cur = conn.cursor()
    if num == 1:
        cur.execute("UPDATE outcomes1 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 2:
        cur.execute("UPDATE outcomes2 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 3:
        cur.execute("UPDATE outcomes3 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 4:
        cur.execute("UPDATE outcomes4 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 5:
        cur.execute("UPDATE outcomes5 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 6:
        cur.execute("UPDATE outcomes6 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 7:
        cur.execute("UPDATE outcomes7 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 8:
        cur.execute("UPDATE outcomes8 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 9:
        cur.execute("UPDATE outcomes9 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 10:
        cur.execute("UPDATE outcomes10 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 11:
        cur.execute("UPDATE outcomes11 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 12:
        cur.execute("UPDATE outcomes12 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 13:
        cur.execute("UPDATE outcomes13 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 14:
        cur.execute("UPDATE outcomes14 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 15:
        cur.execute("UPDATE outcomes15 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 16:
        cur.execute("UPDATE outcomes16 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    elif num == 17:
        cur.execute("UPDATE outcomes17 SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    
    elif num == "m":
        cur.execute("UPDATE master_list SET strngy = Element1_i || Element1_r ||  Element2_i || Element2_r || Element3_i || Element3_r || Element4_i || Element4_r;")
    conn.commit()
    conn.close()
