def sow_data(data_base,my_matrix,num):  # matrix will be a 1x 8 list of [('00001', '00001', '00001', '1','00004', '2', '3', '2')]

    import sqlite3 as lite
    filename = str('%s'%data_base)+str('.db')
    conn = lite.connect(filename)
    cur = conn.cursor()
    if num == 1:
        cur.executemany("INSERT INTO outcomes1 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 2:
        cur.executemany("INSERT INTO outcomes2 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 3:
        cur.executemany("INSERT INTO outcomes3 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 4:
        cur.executemany("INSERT INTO outcomes4 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 5:
        cur.executemany("INSERT INTO outcomes5 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 6:
        cur.executemany("INSERT INTO outcomes6 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 7:
        cur.executemany("INSERT INTO outcomes7 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 8:
        cur.executemany("INSERT INTO outcomes8 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 9:
        cur.executemany("INSERT INTO outcomes9 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 10:
        cur.executemany("INSERT INTO outcomes10 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 11:
        cur.executemany("INSERT INTO outcomes11 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 12:
        cur.executemany("INSERT INTO outcomes12 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 13:
        cur.executemany("INSERT INTO outcomes13 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 14:
        cur.executemany("INSERT INTO outcomes14 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 15:
        cur.executemany("INSERT INTO outcomes15 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 16:
        cur.executemany("INSERT INTO outcomes16 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    elif num == 17:
        cur.executemany("INSERT INTO outcomes17 VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    
    elif num == "m":
        cur.executemany("INSERT INTO master_list VALUES(?,?,?,?,?,?,?,?);",my_matrix)
    conn.commit()
    conn.close()

    
        

    
