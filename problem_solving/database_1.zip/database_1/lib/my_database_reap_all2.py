#my_database_reap_all2.py

def reap_data_outcomes(data_base,num): # returns a complex number array

    import sqlite3 as lite
    import numpy as np
    filename = str('%s'%data_base)+str('.db')
    conn = lite.connect(filename)
    cur = conn.cursor()
    if num == 1:
        cur.execute("SELECT * FROM outcomes1;")
    elif num == 2:
        cur.execute("SELECT * FROM outcomes2;")
    elif num == 3:
        cur.execute("SELECT * FROM outcomes3;")
    elif num == 4:
        cur.execute("SELECT * FROM outcomes4;")
    elif num == 5:
        cur.execute("SELECT * FROM outcomes5;")
    elif num == 6:
        cur.execute("SELECT * FROM outcomes6;")
    elif num == 7:
        cur.execute("SELECT * FROM outcomes7;")
    elif num == 8:
        cur.execute("SELECT * FROM outcomes8;")
    elif num == 9:
        cur.execute("SELECT * FROM outcomes9;")
    elif num == 10:
        cur.execute("SELECT * FROM outcomes10;")
    elif num == 11:
        cur.execute("SELECT * FROM outcomes11;")
    elif num == 12:
        cur.execute("SELECT * FROM outcomes12;")
    elif num == 13:
        cur.execute("SELECT * FROM outcomes13;")
    elif num == 14:
        cur.execute("SELECT * FROM outcomes14;")
    elif num == 15:
        cur.execute("SELECT * FROM outcomes15;")
    elif num == 16:
        cur.execute("SELECT * FROM outcomes16;")
    elif num == "m":
        cur.execute("SELECT * FROM master_list;")

        
    sql_rs = cur.fetchall()
    
    conn.commit()
    
    sql_new = []
    
    for row in sql_rs:
        
        #print("row", row)
        a = complex(row[0],row[1])
        sql_new.append(a)
        b = complex(row[2],row[3])
        sql_new.append(b)
        c = complex(row[4],row[5])
        sql_new.append(c)
        d = complex(row[6],row[7])
        sql_new.append(d)
        
    sql_n = np.array(sql_new,dtype = complex)
    

    return sql_new
