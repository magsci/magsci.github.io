# create_col
def c_col(data_base,num):
    import sqlite3 as lite
    filename = str('%s'%data_base)+str('.db')
    conn = lite.connect(filename)
    cur = conn.cursor()
    if num == 1:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes1 ADD strngy TEXT; """)
    if num == 2:
        ##print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes2 ADD strngy TEXT; """)
    if num == 3:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes3 ADD strngy TEXT; """)
    if num == 4:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes4 ADD strngy TEXT; """)
    if num == 5:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes5 ADD strngy TEXT; """)
    if num == 6:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes6 ADD strngy TEXT; """)
    if num == 7:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes7 ADD strngy TEXT; """)
    if num == 8:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes8 ADD strngy TEXT; """)
    if num == 9:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes9 ADD strngy TEXT; """)
    if num == 11:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes11 ADD strngy TEXT; """)
    if num == 12:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes12 ADD strngy TEXT; """)
    if num == 13:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes13 ADD strngy TEXT; """)
    if num == 14:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes14 ADD strngy TEXT; """)
    if num == 15:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes15 ADD strngy TEXT; """)
    if num == 16:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes16 ADD strngy TEXT; """)
    if num == 17:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes17 ADD strngy TEXT; """)
    if num == 10:
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE outcomes10 ADD strngy TEXT; """)
    if num == 'm':
        #print("found table, adding a column")
        cur.execute("""ALTER TABLE master_list ADD strngy TEXT; """)


    conn.commit()
    conn.close()
