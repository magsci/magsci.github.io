# this will reformat a 1xn list ot a (n/4)x2x2 np array
def reformat(my_array):
    import numpy as np
    length = len(my_array)
    m_no = int(length/4)
    my_array = np.array(my_array)
    my_array = my_array.reshape(m_no,2,2)
    return my_array
