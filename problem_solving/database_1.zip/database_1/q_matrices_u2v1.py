def main():
    import numpy as np
    import sqlite3
    import lib.three_matrices_data as three_matrix
    import lib.my_database_sow_all2 as sow
    import lib.qu_table_create_fn as create
    import lib.my_database_reap_all2 as reap
    import lib.query_table_delete_fnv1 as delete
    import lib.dot_prod as dp
    import lib.reformat_array_m as rf
    import lib.reformat_array3d_2d as rf32
    import lib.reformat_array as rf13
    import lib.q_db_table_u_records_fn as g_unique
    import lib.generate_data_filec_r as real_coeff
    import lib.q_db_table_records_fn as get
    import lib.delete_col as dc
    import lib.create_col as cc
    import lib.generate_strngy_data as gsd
    import lib.del_intersction_t as di

    # this version will deal with duplicates through sql
    #this section deals with the first entries to first table and master list

    d_base = input("enter name of database")
    create.create_table(d_base,1)
    create.create_table(d_base,'m')
    ans = input("does data exist in the data base ? y/n  ")
    if ans == 'n':
        three_matrix.three_matrices(d_base)

    #This section  produces the data which will be written to the next table.
    #this will take the data from i=1...n and perform the dot product with the three matrices which
    # are written into the code.


    max_num = int(input("What is the final outcome number"))
    start = int(input("Numberof last table with data?  "))
    for i in range(start,(max_num)):
        my_array = reap.reap_data_outcomes(d_base,i)
        my_array = rf.reformat(my_array)
        create.create_table(d_base,i+1)
        my_new_array = dp.dot_product(my_array)
        my_new_array = rf32.reformat(my_new_array)

        # my_new_array is the outcomes after the dot product has been performed
        
        #input("Data hs been collected and calculated. Continue to check for duplicates ? ")
        
        #this array of outcomes needs to be checked for duplicates after being
        #written to the database
        #print("length before exporting ",len(my_new_array))
        
        my_new_array = real_coeff.data_gen(my_new_array)
        print("iteration no ",i)
        #print("length before exporting ",len(my_new_array))
        for p in range(len(my_new_array)):
            sow.sow_data(d_base,my_new_array[p],i+1)
              
        myAu = g_unique.get_all(d_base,i+1)
        #print("array after reimporting ",myAu)
        #print("length after reimporting ",len(myAu))
        if len(myAu) < len(my_new_array):
            #print("duplicates")
            delete.delete_table(d_base,i+1)
            create.create_table(d_base,i+1)
        
            for p in range(len(myAu)):
                data = np.array(myAu[p],dtype = float)
                data = data.reshape(1,8)
                data = data.tolist()
                sow.sow_data(d_base,data,i+1)
        
        #input("Continue? ")
        #this section needs to find any records that are common to outcomes(i+1)and maste_list.
        #This will then remove tham from outcomes(i+1) by generating strny data field and
        #comparing on the basis of this field with concatenated data
        # then outcomes(i+1) can be written to master list
        cc.c_col(d_base,i+1)
        gsd.make_strng(d_base,i+1)
        di.d_inter(d_base,i+1)
        dc.d_col(d_base,i+1)
        myAun = get.get_all(d_base,i+1)
        #print("array after removing records already in master_list ",myAun)
        #print("length  ",len(myAun))
        for p in range(len(myAun)):
            data = np.array(myAun[p],dtype = float)
            data = data.reshape(1,8)
            data = data.tolist()
            sow.sow_data(d_base,data,'m')
main()
       
  
        
        
        
    
    
    
