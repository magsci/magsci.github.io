#The purpose of this program is to produce a product of h tand s of any number


def gen_hts():
    
    import numpy as np
    
    import math
    import cmath
    
    import lib.enter_matrix as enter_m # fn my_matrix lib.
    import lib.gen_names as names  # function g_names lib.

    def get_matrix(ans):
        root2 = math.sqrt(2)
        h = np.array([[complex(1/root2,0),complex(1/root2,0)],[complex(1/root2,0),complex(-1/root2,0)]],dtype = complex)
        t = np.array([[1,0],[0,complex(1/root2,1/root2)]],dtype = complex)
        s = np.array([[1,0],[0,complex(0,1)]],dtype = complex)
        if ans=="h":
            my_matrix = h
        if ans=="t":
         my_matrix = t
        if ans=="s":
            my_matrix = s
        return my_matrix
    print("""\n\nThis program will produce the dot product of h s and t matrices.
            It will also produce the dot product for any combination of these gates. 
            Please enter the combination of gates you wish to calculate, e.g. hts
            ______________________________________________________________________\n\n""")

    comb = input("enter the letters for your combination   ")
    numb = len(comb)
    print("Your combination has  ",numb," gates")
    my_ans = []
    rev_ans = []
    allowed = ["h","t","s"]
    i_v =int(0)
    for i in range(numb):
        ans = comb[i]
        if ans in allowed:
            my_ans.append(ans)
        else:
            input("\n Invalid letter, press any ket to quit\n")
            i_v =int(1)
            break
                
    if i_v == 0:
        
        for i in reversed(my_ans):
            rev_ans.append(i)
        

        prod = []

        for i in range(numb):
            ans = rev_ans[i]
            
            
            my_matrix = get_matrix(ans)
            if i == 0:
                prod = my_matrix
                
            else:
                my_matrix_next = get_matrix(ans)
                prod = np.dot(my_matrix_next,prod)
        print("_____________________________________________\n")
                
        print("\nfinal prod   ", prod,"\n")

    else:
        input("\npress return to quit\n")
    

    
    


             

