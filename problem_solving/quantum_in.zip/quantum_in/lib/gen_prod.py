def gen_prod(angle_1,angle_2):
    import numpy as np
    import sqlite3 as lite
    import math
    import cmath
    """import lib.my_database_reap_all_eigen as get
    import root_eigen1  #function is r_e(array1,array2)
    import lib.qu_eigen_table_create_fn as eigen_table #fn cr_eigen_table(data_base)
    import lib.enter_matrix_fn1 as enter_m # fn my_matrix
    import lib.gen_names as names  # function g_names"""
    import lib.calculate_phi_2 as p2 #phi_22(my_array)
    import lib.calculate_phi_1 as p1 #phi_21(my_array)
    import lib.gen_v_matrix1 as gv # function  gen_v(sin angle)
    import lib.gen_w_matrix1 as gw # function gen_w(sin angle)
    import lib.generate_data_filec_r as data # data_gen(myarray)
    
    print("\n Solution using solution 1, ", angle_1,"\n\n")    

    v = gv.gen_v(angle_1)
    v = np.array(v)
    v = np.matrix(v)
    v_dagger = v.getH()
    
    w = gw.gen_w(angle_1)
    w = np.array(w)
    w = np.matrix(w)
    w_dagger = w.getH()
    print("v  matrix  ",v)
    print("v_dagger  matrix  ",v_dagger)
    print("w matrix   ",w)
    
    print("w_dagger matrix   ",w_dagger)

    prod1 = np.dot(v_dagger,w_dagger)
    prod2 = np.dot(v,w)
    prod3 = np.dot(prod2,prod1)

    print("prod3  vwv_daggerw_dagger  ",prod3)

    print("\n Solution using solution 2, ", angle_2,"\n\n")    

    v = gv.gen_v(angle_2)
    v = np.array(v)
    v = np.matrix(v)
    v_dagger = v.getH()
    
    w = gw.gen_w(angle_2)
    w = np.array(w)
    w = np.matrix(w)
    w_dagger = v.getH()
    print("v  matrix  ",v)
    print("v_dagger  matrix  ",v_dagger)
    print("w matrix   ",w)
    
    print("w_dagger matrix   ",w_dagger)

    prod1 = np.dot(v_dagger,w_dagger)
    prod2 = np.dot(w,prod1)
    prod3 = np.dot(v,prod2)

    print("prod3  vwv_daggerw_dagger  ",prod3)
    
