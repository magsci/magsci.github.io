def gen_prod(angle_1,angle_2):
    import numpy as np
    
    import math
    import cmath
    
    import lib.gen_v_matrix_test as gv # function  gen_v(sin angle) lib.
    import lib.gen_w_matrix_test as gw # function gen_w(sin angle)lib.
    
    
    print("\n Solution using sin phi/2 -solution 1, ", angle_1,"\n\n")    

    v = gv.gen_v(angle_1)
    v = np.array(v)
    v = np.matrix(v)
    v_dagger = v.getH()
    
    w = gw.gen_w(angle_1)
    w = np.array(w)
    w = np.matrix(w)
    w_dagger = w.getH()
    prod1 = np.dot(v_dagger,w_dagger)
    prod2 = np.dot(v,w)
    prod3 = np.dot(prod2,prod1)

    print("product  v.w.v_dagger.w_dagger  ",prod3)

    print("\n Solution using using sin phi/2  solution 2, ", angle_2,"\n\n")    

    v = gv.gen_v(angle_2)
    v = np.array(v)
    v = np.matrix(v)
    v_dagger = v.getH()
    
    w = gw.gen_w(angle_2)
    w = np.array(w)
    w = np.matrix(w)
    w_dagger = v.getH()
    

    prod1 = np.dot(v_dagger,w_dagger)
    prod2 = np.dot(w,prod1)
    prod3 = np.dot(v,prod2)

    print("product   v.w.v_dagger.w_dagger  ",prod3)
    
