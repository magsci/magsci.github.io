def gen_w(s_p_2):  #sin_phi need to reset bac to same as gen_v_matrix
    
    import math
    import cmath
    import numpy as np
    
    id_matrix = [[1 if i == j else 0 for i in range(2)] for j in range(2)]
    s_matrix = [[0 if i == j else 1 for i in range(2)] for j in range(2)]
    
    t_matrix = [[0,0.0-1.0j],[0+1.0j,0]]
    
    c_p_2 = math.sqrt(1-(s_p_2)*(s_p_2))
    #print("c_p_2 ",c_p_2 )
    a = c_p_2
    b = (-s_p_2)*(0.0 +1.0j)
    term1 = np.dot(a,id_matrix)
    term2 = np.dot(b,t_matrix)
    
    #print("\n____________________________________\n")
    w = term1 + term2
    #print("w  ",w)
    return w
    
  
