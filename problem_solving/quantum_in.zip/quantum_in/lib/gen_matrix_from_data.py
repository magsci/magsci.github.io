"""this will take the list of nx 1x8 lists and reconstruct the complex numbers to out put a list of 1x4
matrices whcih can be used in dot product module
input data [[(1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 2.0)],
[(1.0, 1.0, 1.0, 2.0, 1.0, 1.0, 1.0, 2.0)]]"""
def c_data_gen(myarray):
    import numpy as np
    import math
    import cmath
    l_m = len(myarray)
    myarray = np.array(myarray)
    #print("size ",myarray.size,"shape ",myarray.shape,"datatype ",myarray.dtype,"lenght ",l_m)
    myarray = myarray.reshape(l_m,8)
    #print("size reshaped ",myarray.size,"shape ",myarray.shape,"datatype ",myarray.dtype,"lenght ",l_m)
    
    data_list = []
    
    for i in range(l_m):
        a = complex(myarray[i][0],myarray[i][1])
        b = complex(myarray[i][2],myarray[i][3])
        c = complex(myarray[i][4],myarray[i][5])
        d = complex(myarray[i][6],myarray[i][7])
        data = [a,b,c,d]
        

        
        
        data_list.append(data)
    
    dl_l = len(data_list)
    data_list = np.array(data_list)
    data_list = data_list.reshape(dl_l,2,2)
    #print("size data_list ",data_list.size,"shape ",data_list.shape,"datatype ",data_list.dtype,"lenght ",len(data_list))
    """ example of output data:  array([[[1.+0.j, 1.+1.j],
        [0.+0.j, 1.+2.j]],

       [[1.+1.j, 1.+2.j],
        [1.+1.j, 1.+2.j]]])"""
        
        
    return data_list
    
