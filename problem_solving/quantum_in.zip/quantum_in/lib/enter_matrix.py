def my_matrix():
    import numpy as np
    import math
    import cmath

    def entry_type(number):
        q1 = input("is the number in complex form? if so Enter as complex , e.g 1.0+1.0j, enter y or  n\n")
        if q1 == "y":
            
            a = complex(input("enter your value \n "))
            print("a  ",a)
            number.append(a)
        elif q1 == "n":
            q3 = input("is your value in exponetial (exp (i*n*pi))  form, n can be fractional and negative ?  y/n \n ")
            if q3 =="y":
                nn = float(input("enter your value of n \n "))
                ag = nn*(math.pi)
                a = complex(math.cos(ag),math.sin(ag))
                print("a  ",a)
                number.append(a)
        else:
            print(" you have entered an invalid character")
        return number

    R = 2  #int(input("Enter the number of rows:")) 
    C = 2   #int(input("Enter the number of columns:")) 

    
    print("""Enter the entries for 2x2 complex matrix, e.g 1.0+1.0j
            
             in a single line (separated by space)
             A{00} A{01] A[10] A[11] :

             """)
    print("\n","___________________________________________________________","\n")

    # User input of entries in a 
    # single line separated by space
    
    number = []
    for n in range(4):
        print(n+1,"value   ")
        q1 = input("is the number in complex form? if so Enter as complex , e.g 1.0+1.0j, enter y or  n\n")
        if q1 == "y":
            
            a = complex(input("enter your value \n "))
            print("a  ",a)
            number.append(a)
        elif q1 == "n":
            q3 = input("is your value in exponetial (exp (i*n*pi))  form, n can be fractional and negative ?  y/n \n ")
            if q3 =="y":
                nn = float(input("enter your value of n \n "))
                ag = nn*(math.pi)
                a = complex(math.cos(ag),math.sin(ag))
                print("a  ",a)
                number.append(a)
        else:
            print(" you have entered an invalid character\n")
                
     
        

    
    #entries = list(map(complex,number))   #input().split()
    #print("entries  ",entries)

    # For printing the matrix 
    matrix = np.array(number).reshape(R, C)
    
    
        
        
    a = matrix[0][0].real
    b = matrix[0][0].imag
    c = matrix[0][1].real
    d = matrix[0][1].imag
    e = matrix[1][0].real
    f = matrix[1][0].imag
    g = matrix[1][1].real
    h = matrix[1][1].imag
    

    data = [(a,b,c,d,e,f,g,h)]
    print("matrix  :",matrix)
    print("\n","___________________________________________________________","\n")

    return data
