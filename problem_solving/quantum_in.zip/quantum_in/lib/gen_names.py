# gen_names.py  this queries master_listd for matricces when atringy is given

def g_names(data_base,string):
    import sqlite3 as lite
    filename = str('%s'%data_base)+str('.db')
    conn = lite.connect(filename)
    cur = conn.cursor()

    sql_update_query = """SELECT matrices from master_listd where stringy = ?"""
    cur.execute(sql_update_query, (string, ))
    conn.commit()
    
    sql_rs = cur.fetchall()
    
    conn.commit()
    
    
    

    return sql_rs
    conn.commit()
    conn.close()
    
