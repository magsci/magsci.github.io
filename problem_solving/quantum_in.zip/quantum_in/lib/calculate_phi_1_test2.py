def phi_21(my_array):  # returns sin_phi/2
    import numpy as np
    import math
    import cmath
    import lib.gen_matrix_from_data as mtrx # c_data_gen(myarray)
    #import gen_matrix_from_data as mtrx # c_data_gen(myarray)

    def find_phi(my_array):
        
        #my_array =  [(0.707106781,0,0.707106781,0,0.707106781,0,-0.707106781,0,)]
        my_matrix = mtrx.c_data_gen(my_array)
        
        return my_matrix
    
    new_matrix = find_phi(my_array)
    new_matrix = np.array(new_matrix)    #np.array(new_matrix)
    new_matrix = new_matrix.reshape(2,2)
    
    a = np.trace(new_matrix)
    a_r= (a.real)/2  #]cos(theta/2)
    #print("a  ",a,"a-r aks  cos(theta/2) ",a_r)
    
    #a_n =math.sqrt(1- a_r*a_r) # a_n is sin(theta/2)
    #print("a_n  ",a_n)
    # b is the square of a_n this will be sin(theata)/2 squared
    b = (1- a_r*a_r)  #sin (theta/2) squared
    quad1 = math.sqrt(1-b)
    #quad1 = a_r
    quad21 = 0.5*(1+quad1)
    quad22 = 0.5*(1-quad1)
    s_phi_21 = math.sqrt(math.sqrt(quad21))
    s_phi_22 = math.sqrt(math.sqrt(quad22))
    #phi_21 = 2*math.asin(s_phi_21)
    #phi_22 = 2*math.asin(s_phi_22)

    #print(" phi/2 in  first solutiion  :",phi_21)
    #print(" phi/2 in  next solutiion  :",phi_22)
    #return phi_21
    return s_phi_21
    
    


