def main():
    import numpy as np
    import math
    import cmath
    import lib.calculate_phi_1_test2 as s_phi2_1
    import lib.calculate_phi_2_test2 as s_phi2_2
    import lib.gen_hts as hts
    import lib.gen_v_matrix_test as gv
    import lib.gen_w_matrix_test as gw
    import lib.gen_prod_test as gen_prod
    import lib.enter_matrix as enter
    

    print(""" The tasks in this program are:

              1. Generate a matrix from a combination of h t and s gates

              2. Calculate sin phi/2 for a user input matrix

              3. Generate v for the value of sin phi/2 from task 2

              4. Generate  for the value of sin phi/2 from task 2

              5 Calculate the product  v.w.v_dagger.w_dagger\n""")
    selection = int(input("enter the task number  "))
    if selection == 1:
        hts.gen_hts()
        cont_1 = input("Do you wish to select this task again?  y/n  ")
        while cont_1 =="y":
            hts.gen_hts()
            cont_1 = input("Do you wish to select this task again?  y/n  ")
        if cont_1 == 'n':
            print("task ended")
        else:
            print("invalid answer")
            input("\nPress any key to quit\n")

            
    elif selection == 2:
        print("the array should be in the form: [(0.707106781,0,0.707106781,0,0.707106781,0,-0.707106781,0,)]")
        my_array = enter.my_matrix()
        
        
        s_angle_1 = s_phi2_1.phi_21(my_array)
        s_angle_2 = s_phi2_2.phi_21(my_array)
        print("sin phi/2  solution1",s_angle_1,"solution 2  ",s_angle_2)
        cont_2 = input("Do you wish to select this task again?  y/n  ")
        while cont_2 =="y":
            my_array = enter.my_matrix()
            s_angle_1 = s_phi2_1.phi_21(my_array)
            s_angle_2 = s_phi2_2.phi(my_array)
            print("sin phi/2  solution1",s_angle_1,"solution 2  ",s_angle_2)
            cont_2 = input("Do you wish to select this task again?  y/n  ")
        if cont_2 == 'n':
            print("task ended")
        else:
            print("invalid answer")
            input("\nPress any key to quit\n")
    elif selection == 3:
         print("This will generate v for the value of sin phi/2 from task 2")
         s_p_2 = float(input("enter value of sin phi/2"))
         v = gv.gen_v(s_p_2)
         print("The matrix v corresponding to your value of sin phi/2 is: ",v)
         cont_3 = input("Do you wish to select this task again?  y/n  ")
         while cont_3 == "y":
             s_p_2 = float(input("enter value of sin phi/2"))
             v = gv.gen_v(s_p_2)
             print("The matrix v corresponding to your value of sin phi/2 is: ",v)
             cont_3 = input("Do you wish to select this task again?  y/n  ")
         if cont_3 == 'n':
             print("task ended")
         else:
             print("invalid answer")
             input("\nPress any key to quit\n")
    elif selection == 4:
         print("This will generate w for the value of sin phi/2 from task 2")
         s_p_2 = float(input("enter value of sin phi/2"))
         w = gw.gen_w(s_p_2)
         print("The matrix w corresponding to your value of sin phi/2 is: ",w)
         cont_4 = input("Do you wish to select this task again?  y/n  ")
         while cont_4 == "y":
             s_p_2 = float(input("enter value of sin phi/2"))
             w = gw.gen_w(s_p_2)
             print("The matrix w corresponding to your value of sin phi/2 is: ",w)
             cont_4 = input("Do you wish to select this task again?  y/n  ")
         if cont_4 == 'n':
             print("task ended")
         else:
             print("invalid answer")
             input("\nPress any key to quit\n")

    elif selection == 5:
         print("This will generate product v.w.v_d.w_d for the values (2 solutions)of sin phi/2 from task 2")
         angle_1 = float(input("enter solution 1   "))
         angle_2 = float(input("enter solution 2  "))
         gen_prod.gen_prod(angle_1,angle_2)  
        
         cont_5 = input("Do you wish to select this task again?  y/n  ")
         while cont_5 == "y":
             print("This will generate product v.w.v_d.w_d for the values (2 solutions)of sin phi/2 from task 2")
             angle_1 = float(input("enter solution 1   "))
             angle_2 = float(input("enter solution 2  "))

             gen_prod.gen_prod(angle_1,angle_2)               
         
        
             cont_5 = input("Do you wish to select this task again?  y/n  ")
         if cont_5 == 'n':
             print("task ended")
         else:
             print("invalid answer")
             input("\nPress any key to quit\n")
main()
cont = input("Do you wish to select another task?  y/n  ")
if cont =="y":
    main()

else:
    input("\n\nEnter  q to quit  \n")
